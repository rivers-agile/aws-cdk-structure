#!/bin/bash
node /home/ec2-user/test-app/bin/www
