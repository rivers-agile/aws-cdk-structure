#!/bin/bash
killall node
